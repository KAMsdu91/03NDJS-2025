let users = []; // stockage en mémoire
module.exports = users;